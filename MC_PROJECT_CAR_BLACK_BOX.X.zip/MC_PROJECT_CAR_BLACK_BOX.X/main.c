/*
 * File:   main.c
 * Author: POOJA ZORE
 * project Name : CAR BLACK BOX
 * description : This system essentially acts as a black box for a vehicle, recording crucial information such as time, 
 *               event types, and speed. It's useful for monitoring driving behavior, diagnosing issues, or providing
 *               evidence in case of accidents. The system combines several hardware components (LCD, keypad, ADC, RTC, EEPROM)
 *               and integrates them into a cohesive software program that allows for real-time monitoring and data storage.
 *
 * 
 * Created on 9th DECEMBER, 2024
 */

#include "black_box.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "adc.h"
#include "uart.h"
#include "i2c.h"
#include "ds1307.h"
#include "external_eeprom.h"
#include<string.h>

State_t state;
int index = 0;
 int i=0;
int log = 0;
int log1 = 0;

unsigned int view_index =0 ;
unsigned char E[9][3] = {"C_", "ON", "GN", "G1", "G2", "G3", "G4", "G5", "GR"};
unsigned char time[9];
unsigned  int delay = 0;
unsigned long int Speed;
unsigned char init_dashboard[] = {"  TIME    EV  SP"};
unsigned char key;
int ind = 1;
char address = 0x00;
unsigned short adc_reg_val;
unsigned short view = MIN_GEAR;
unsigned char log_data[4][17] = {"view_log       ", "download_log   ", "clear_log     ", "set_time      "};
//unsigned char key12;
int sp;
unsigned char clock_reg[3];
static int log_index = 0;
int count = 0;

/* event reader veriable*/
unsigned char read_time[10][15];
unsigned char event_type[3]; //(3)
unsigned char speed_data[3];

//SET TIME
int hrs=0,min=0,sec=0;
int flag1 = 0;
int delay1 = 0;


// Initialize all configurations
void init_config() {

    init_clcd();
    init_adc();
    init_i2c();
    init_ds1307();
    init_uart();
    init_matrix_keypad();

    state = e_dashboard; //set the initial state enum veriabl
}

void display_time(void) {
    //print time on the second line 
    clcd_print(time, LINE2(2));

    //checking for AM/PM flag
    if (clock_reg[0] & 0x40) {
        if (clock_reg[0] & 0x20) {
            clcd_print("PM", LINE2(12));
        } else {
            clcd_print("AM", LINE2(12));
        }
    }
}

void get_time(void) {
    //Read the hour register
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    //Read the min register
    clock_reg[1] = read_ds1307(MIN_ADDR);
    //Read the sec register
    clock_reg[2] = read_ds1307(SEC_ADDR);
 
    //checking for 12-hour format
    if (clock_reg[0] & 0x40) {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    } else {
        time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time[1] = '0' + (clock_reg[0] & 0x0F);
    }
    time[2] = ':';
    time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time[4] = '0' + (clock_reg[1] & 0x0F);
    time[5] = ':';
    time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time[7] = '0' + (clock_reg[2] & 0x0F);
    time[8] = '\0';
}


void view_dashboard() {
    
    //call the time function
    get_time();

    //read the speed from to the ADC
    Speed = read_adc(CHANNEL4);
    //convert the ADC to speed
    Speed = Speed * 99 / 1023;



    if (key == MK_SW1) {

        ind = 0;
        event_store();

    }
    if (key == MK_SW2 && ind < 8) {

        //move to the next event
        ind++;
        //store the event function
        event_store();

    }
    if (key == MK_SW3 && ind > 2) {
        ind--;
        event_store();
    }
    if (key == MK_SW11) 
    {
     state = e_main_menu;
    }
    
    log1 = 0;
    //print dashboard
    clcd_print(init_dashboard, LINE1(0));
    //print the time
    clcd_print(time, LINE2(0));

    
    //display the speed
    clcd_putch('0' + (Speed / 10), LINE2(14));
    clcd_putch('0' + (Speed % 10), LINE2(15));

    //display the event
    clcd_print(E[ind], LINE2(10));
}

void event_store() {


    for (int i = 0; i < 8; i++) {
        //write_internal_eeprom(address++,time[i]);
        write_external_eeprom(address++, time[i]);


    }
    //store the event and speed
    write_external_eeprom(address++, E[ind][0]);
    write_external_eeprom(address++, E[ind][1]);

    write_external_eeprom(address++, Speed / 10 + '0');
    write_external_eeprom(address++, Speed % 10 + '0');


    if (address >= 120) {
        address = 0;
    }

    //increment event count
    count++;


}

//main menu function declaration

void display_main_menu() {

    //switch 12 increment to the index 
    if (key == MK_SW12 && index < 3) {
        index++;
    }
    
    //switch 11 decrement to the index 
    if (key == MK_SW11 && index > 0) {
        index--;
    }

    if (!index) {
        clcd_print("->", LINE1(0));
        clcd_print(log_data[index], LINE1(2));
        clcd_print("  ", LINE2(0));
        clcd_print(log_data[index + 1], LINE2(2));
    } else {
        clcd_print("  ", LINE1(0));
        clcd_print(log_data[index - 1], LINE1(2));
        clcd_print("->", LINE2(0));
        clcd_print(log_data[index], LINE2(2));
    }


    if (key == MK_SW1 && index == 0) 
    {
        //switch 1 and index 0 go to the view_log
        state = e_view_log;
    }
    else if (key == MK_SW1 && index == 1) 
    {
        //switch 1 and index 1 go to the download_log
        state = e_download_log;
    } 
    else if (key == MK_SW1 && index == 2) 
    {
        //switch 1 and index 2 go to the clear_log
        state = e_clear_log;
    } 
    else if (key == MK_SW1 && index == 3)
    {
        //switch 1 and index 3 go to the set_log
        state = e_set_time;
    }

    if (key == MK_SW2) {
        //switch 2 using for go the dashboard
        state = e_dashboard;
        CLEAR_DISP_SCREEN;

    }
    


}

//View log function declaration

void view_log() {
    //int i=0;
    //log data external eeprom
    if(log1==0 && count >= 1)
    {
    clcd_print("L TIME    EV  SP", LINE1(0));
    }
    //read the event from EEPRORM  and displaying
    event_reader();
    
    //switch 11 increment to the index for view log 
    if(key == MK_SW11 && view_index < count-1){
        view_index++;
    }
    
    if(key == MK_SW12 && view_index > 0){
        //switch 12 decrement to the index
        view_index--;
    }
    
    if(view_index >= 10){
        //view_index up to again index value reset
        view_index = 0;
    }
    if(log1==0)
    {
        
        clcd_putch((view_index+1) + '0',LINE2(0));
        clcd_print(read_time[view_index], LINE2(2));
    }
        
    
    if(key == MK_SW2)
    {
        //go back to the main menu
        state = e_main_menu;
       
    }
    
    if(log1==1)
    {
        //CLEAR_DISP_SCREEN;
        clcd_print("                ",LINE1(0));
        clcd_print("   N0 Log Event    ",LINE2(0));
    }
    if(count == 0){
        view_index = 0;
        //when count value no increment after printing
        clcd_print("                ",LINE1(0));
        clcd_print("   N0 Log Event ",LINE2(0));
    }
 

}

//Reading events function declaration

void event_reader() {

    char add = 0;

    //upto loop run in the log events from EEPROM
    for (int i = 0; i < count; i++) {
        //read 8 bytes time data from EEPROM

        for (int j = 0; j < 15; j++) {
            if (j == 8 || j == 11) {
                read_time[i][j] = '  ';
            } else if (j == 14) {
                read_time[i][j] = '\0';
            } else
                read_time[i][j] = read_external_eeprom(add++);//store 2d array for the  all log event
            
        }
    }

}

//Set time function declaration
void print_clcd(void)
{
    //print the hour
    clcd_putch(hrs/10 + '0', LINE2(4));
    clcd_putch(hrs%10 + '0', LINE2(5));
    
    clcd_putch(':', LINE2(6));
    
    //print the min
    clcd_putch(min/10 + '0', LINE2(7));
    clcd_putch(min%10 + '0', LINE2(8));
    
    clcd_putch( ':', LINE2(9));
    
    //print the sec
    clcd_putch(sec/10 + '0', LINE2(10));
    clcd_putch(sec%10 + '0', LINE2(11));
    
}

void set_time(void)
{
    clcd_print("    HH:MM:SS    ", LINE1(0));
    clcd_print("    ", LINE2(0));
    clcd_print("    ", LINE2(12));
    if(flag1 == 0)
    {
        hrs = ((time[0]- '0')*10) + (time[1]- '0');
        min = ((time[3]- '0')*10) + (time[4]- '0');
        sec = ((time[6]- '0')*10) + (time[7]- '0');
        flag1++;
    }
    if (key == MK_SW11) {
    if (flag1 == 1) {  // Increment hours
        if (++hrs == 24) {
            hrs = 0;
        }
    } else if (flag1 == 2) {  // Increment minutes
        if (++min == 60) {
            min = 0;
        }
    } else if (flag1 == 3) {  // Increment seconds
        if (++sec == 60) {
            sec = 0;
        }
    }
}
    
    if(flag1 == 1)
    { 
        if(delay1++ <= 500)
        {
            //function call for edit time 
            print_clcd();
        }
        else if(delay1++ <= 1000)
        {
           clcd_print("  ",LINE2(4));
        }
        else 
        {
            delay1 = 0;
        }
    }
    
    if(flag1 == 2)
    { 
        if(delay1++ <= 500)
        {
            print_clcd();
        }
        else if(delay1++ <= 1000)
        {
           clcd_print("  ",LINE2(7));
        }
        else 
        {
            delay1 = 0;
        }
    }
    
    if(flag1 == 3)
    { 
        if(delay1++ <= 500)
        {
            print_clcd();
        }
        else if(delay1++ <= 1000)
        {
           clcd_print("  ",LINE2(10));
        }
        else 
        {
            delay1 = 0;
        }
    }
    
    

    
    if( key == MK_SW12 )
    {
        if(++flag1 == 4)
        {
            flag1 = 1;
        }
    }   
    if(key == MK_SW1)
    {
        //switch 1 using for save and exit for the edit time rest the time
        write_ds1307(HOUR_ADDR, (((hrs/10) << 4) | (hrs % 10)));
        write_ds1307(MIN_ADDR, (((min/10) << 4) | (min % 10)));
        write_ds1307(SEC_ADDR, (((sec/10) << 4) | (sec % 10)));
        
        state = e_main_menu;//time editing after the go back to the main_menu
    }
    if(key == MK_SW2)
    {
        state = e_main_menu;
    }
    
}
//Download log function _decleration

void download_log() {
    
    event_reader();
           // state = e_main_menu;

    clcd_print("Download     ", LINE1(0));
    clcd_print("      Successful     ", LINE2(0));
     
    if(delay++ == 100)
    {
        delay = 0;
        state = e_dashboard;
        CLEAR_DISP_SCREEN;
        
        puts("L TIME    EV  SP");
        puts("\n\r");
        //only for downloading for the 10 logs
        for(int i=0; i<10; i++)
        {
            puts("\n\r");
            putch((i+1) + '0');
            putch(' ');
            //send for the uart 
            puts(read_time[i]);
            puts("\n\r");
           
        }
        puts("Download Log Successfully\n\r");
    }
     
    
    if(key == MK_SW2)
    {
        state = e_main_menu;
    }

}

//Clear log function declaration

void clear_log() {
    
    clcd_print("  Cleared       ",LINE1(0));
    clcd_print("    Successful  ",LINE2(0));
    
    if(delay++ == 1000){
        delay = 0;
        state = e_main_menu;
    }
    
    for(int i=0; i < count; i++){
        for(int j=0; j<15; j++){
            read_time[i][j] = ' ';
        }
    }
    
    log1 = 1;
    //count value is 0 because all logs cleraing
    count = 0;

}

void main(void) {

    init_config();

    while (1) {

        key = read_switches(STATE_CHANGE);
        switch (state) {
            case e_dashboard:
                // Display dashboard

                view_dashboard();
                break;

            case e_main_menu:
                // Display dashboard
                display_main_menu();
                break;

            case e_view_log:
                // Display dashboard
                view_log();
                break;

            case e_download_log:
                download_log();
                break;

            case e_clear_log:
                clear_log();
                break;


            case e_set_time:
                set_time();
                break;

        }

    }

}