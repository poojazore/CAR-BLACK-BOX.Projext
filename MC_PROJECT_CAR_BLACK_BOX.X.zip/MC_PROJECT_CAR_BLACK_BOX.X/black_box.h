#ifndef BLACK_BOX_H
#define BLACK_BOX_H

#include <xc.h>

typedef enum{
    e_dashboard, e_main_menu, e_view_log, e_set_time, e_download_log, e_clear_log
}State_t;

#define MAX_LOG     10
#define MSG_LENGTH  14
#define COLLISION   0
#define NINE_ADD    0x07E
#define MAX_ADD     0x08C
#define INIT_ADD    0x00
#define MIN_GEAR    1

extern State_t state;

void view_dashboard();

void read_log_event();

void event_store();

void display_main_menu();

void view_log();

void event_reader();

void set_time();

void download_log();

void clear_log();

#endif